var people = [
    {
        "id": 1,
        "first_name": "Walliwsaasa",
        "last_name": "Spurden",
        "email": "wspurden0@reverbnation.com",
        "gender": "Female",
        "edad": 25,
        "active": "true"
        , "tipo": "Senador"
    },
    {
        "id": 2,
        "first_name": "Calley",
        "last_name": "Albion",
        "email": "calbion1@goodreads.com",
        "gender": "Female",
        "edad": 25,
        "active": "false", "tipo": "Senador"
    },
    {
        "id": 3,
        "first_name": "Juan",
        "last_name": "Shearsby",
        "email": "jshearsby2@discovery.com",
        "gender": "Male",
        "edad": 25,
        "active": "false", "tipo": "Diputado"
    },
    {
        "id": 4,
        "first_name": "Carlyn",
        "last_name": "Jarnell",
        "email": "cjarnell3@dedecms.com",
        "gender": "Female",
        "edad": 25,
        "active": "true"
        , "tipo": "Diputado"
    },
    {
        "id": 5,
        "first_name": "Maegan",
        "last_name": "Lowbridge",
        "email": "mlowbridge4@drupal.org",
        "gender": "Female",
        "edad": 25,
        "active": "false", "tipo": "Diputado"
    },
    {
        "id": 6,
        "first_name": "Ambur",
        "last_name": "Aloway",
        "email": "aaloway5@pinterest.com",
        "gender": "Male",
        "edad": 25,
        "active": "true"
        , "tipo": "Diputado"
    },
    {
        "id": 7,
        "first_name": "Merola",
        "last_name": "Bartocci",
        "email": "mbartocci6@mozilla.com",
        "gender": "Female",
        "edad": 25,
        "active": "false", "tipo": "Senador"
    },
    {
        "id": 8,
        "first_name": "Phelia",
        "last_name": "Vaz",
        "email": "pvaz7@linkedin.com",
        "gender": "Female",
        "edad": 25,
        "active": "false", "tipo": "Senador"
    },
    {
        "id": 9,
        "first_name": "Loria",
        "last_name": "Stibbs",
        "email": "lstibbs8@reddit.com",
        "gender": "Male",
        "edad": 25,
        "active": "false", "tipo": "Diputado"
    },
    {
        "id": 10,
        "first_name": "Brockie",
        "last_name": "Tulleth",
        "email": "btulleth9@flavors.me",
        "gender": "Male",
        "edad": 25,
        "active": "false", "tipo": "Diputado"
    },
    {
        "id": 11,
        "first_name": "jessica",
        "last_name": "fukman",
        "email": "jessicafukman@gmail.com",
        "gender": "Male",
        "edad": 25,
        "active": "true",
        "tipo": "Senador"
    },
    {
        "id": 12,
        "first_name": "yty",
        "last_name": "gfd",
        "email": "tre@kill",
        "gender": "Female",
        "edad": 25,
        "active": "false", "tipo": "Diputado"
    },
    {
        "id": 13,
        "first_name": "23423",
        "last_name": "234234",
        "email": "sdf@mail.com",
        "gender": "Male",
        "edad": 25,
        "active": "false", "tipo": "Diputado"
    },
    {
        "id": 14,
        "first_name": "asd",
        "last_name": "asd",
        "email": "asd@mama",
        "gender": "Female",
        "edad": 25,
        "active": "false", "tipo": "Diputado"
    }
]